import sqlite3
import xbmcaddon